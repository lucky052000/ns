### Output

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B5%20(Ping)/output/lab-5_output.png)