### Output

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B6%20(ESS)/output/lab6_output-1.png)

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B6%20(ESS)/output/lab6_output-2.png)

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B6%20(ESS)/output/lab6_output-3.png)